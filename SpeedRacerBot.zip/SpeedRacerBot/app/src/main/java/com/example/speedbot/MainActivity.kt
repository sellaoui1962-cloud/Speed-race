package com.example.speedbot

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.widget.*
import rikka.shizuku.Shizuku

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var auto: CheckBox

    private val permListener = Shizuku.OnRequestPermissionResultListener { _, _ -> refresh() }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48) }
        status = TextView(this).apply { textSize = 16f }
        auto = CheckBox(this).apply { text = "إعادة التحدي تلقائياً (يستهلك تذاكر السباق)" }
        val perm = Button(this).apply { text = "1) طلب صلاحية Shizuku"; setOnClickListener {
            if (Shizuku.pingBinder() && Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED)
                Shizuku.requestPermission(1) else refresh() } }
        val start = Button(this).apply { text = "2) تشغيل البوت"; setOnClickListener {
            val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            startActivityForResult(mpm.createScreenCaptureIntent(), 42) } }
        val stop = Button(this).apply { text = "إيقاف"; setOnClickListener {
            startService(Intent(this@MainActivity, BotService::class.java).setAction("STOP")) } }
        listOf(status, auto, perm, start, stop).forEach { col.addView(it) }
        setContentView(col)
        Shizuku.addRequestPermissionResultListener(permListener)
        if (android.os.Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 0)
        refresh()
    }

    private fun refresh() {
        status.text = when {
            !Shizuku.pingBinder() -> "Shizuku غير يعمل — شغّله أولاً (عبر ADB اللاسلكي)"
            Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED -> "Shizuku يعمل — الصلاحية غير ممنوحة"
            else -> "جاهز. شغّل البوت ثم افتح اللعبة واضغط «التحدي» (أو فعّل الإعادة التلقائية)."
        }
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        if (req == 42 && res == RESULT_OK && data != null) {
            startForegroundService(Intent(this, BotService::class.java)
                .putExtra("code", res).putExtra("data", data).putExtra("auto", auto.isChecked))
        }
    }

    override fun onDestroy() { Shizuku.removeRequestPermissionResultListener(permListener); super.onDestroy() }
}
