package com.example.speedbot

import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.max
import kotlin.math.sin

/**
 * تحليل الإطار. يقسّم كل ما على الطريق إلى:
 *  - good: عنصر داخل فقاعة شفافة (علم، مغناطيس، حلقة...) → يُلتقط
 *  - hazard: أي شيء آخر غير الأسفلت (حواجز، مخاريط، حاويات، إطارات) → يُتجنَّب
 *  - العملات الذهبية: تُلتقط أيضاً (good)
 * القيم نسب من ارتفاع الشاشة (قريب من السيارة = قيمة أكبر).
 */
object Vision {
    const val ROAD_L = 0.127f
    const val ROAD_R = 0.875f
    const val LOOK_TOP = 0.10f
    const val LOOK_BOTTOM = 0.725f
    const val HUD_Y = 0.30f
    const val HUD_X = 0.64f

    class Result(
        val car: Int,
        val haz: FloatArray,    // أقرب حافة سفلية لعائق في كل مسار أو -1
        val good: FloatArray,   // أقرب حافة سفلية لعنصر فقاعة أو -1
        val roadFrac: Float,
        val menu: Boolean
    )

    private fun r(p: Int) = p shr 16 and 255
    private fun g(p: Int) = p shr 8 and 255
    private fun b(p: Int) = p and 255

    fun analyze(px: IntArray, w: Int, h: Int): Result {
        val x0 = (ROAD_L * w).toInt(); val x1 = (ROAD_R * w).toInt()
        val lw = (x1 - x0) / 3f

        // السيارة من اللون الأحمر
        var sx = 0L; var n = 0
        for (y in (0.5f * h).toInt() until (0.8f * h).toInt()) for (x in 0 until w) {
            val p = px[y * w + x]
            if (r(p) > 150 && g(p) < 70 && b(p) < 70) { sx += x; n++ }
        }
        var car = -1; var carCx = -1f
        if (n > 20) {
            carCx = sx.toFloat() / n
            car = (((carCx / w - ROAD_L) / (ROAD_R - ROAD_L)) * 3).toInt().coerceIn(0, 2)
        }

        // قناع الأجسام (غير الأسفلت) ضمن منطقة الطريق
        val mask = BooleanArray(w * h)
        val yTop = (LOOK_TOP * h).toInt(); val yBot = (LOOK_BOTTOM * h).toInt()
        val line1 = (x0 + lw).toInt(); val line2 = (x0 + 2 * lw).toInt()
        for (y in yTop until yBot) {
            for (x in x0 until x1) {
                if (y < HUD_Y * h && x > HUD_X * w) continue
                if (abs(x - line1) <= 2 || abs(x - line2) <= 2) continue
                if (car >= 0) {
                    if (y >= (0.52f * h).toInt() && y < (0.73f * h).toInt() && abs(x - carCx) < 0.095f * w) continue
                }
                val p = px[y * w + x]; val rr = r(p); val gg = g(p); val bb = b(p)
                val mx = max(rr, max(gg, bb)); val mn = min(rr, min(gg, bb))
                if (mx < 95 && mx - mn < 40 && bb >= rr - 5) continue          // أسفلت
                if (car >= 0 && bb > rr + 30 && y >= (0.45f * h).toInt() && y < (0.80f * h).toInt()
                    && abs(x - carCx) < 0.3f * w) continue                      // توهج الدرع الأزرق حول السيارة
                mask[y * w + x] = true
            }
        }

        // تمدد 5×5 لربط أجزاء الجسم الواحد
        val tmp = BooleanArray(w * h); val dil = BooleanArray(w * h)
        for (y in 0 until h) for (x in 0 until w) {
            var v = false
            for (dx in -2..2) { val xx = x + dx; if (xx in 0 until w && mask[y * w + xx]) { v = true; break } }
            tmp[y * w + x] = v
        }
        for (y in 0 until h) for (x in 0 until w) {
            var v = false
            for (dy in -2..2) { val yy = y + dy; if (yy in 0 until h && tmp[yy * w + x]) { v = true; break } }
            dil[y * w + x] = v
        }

        val haz = FloatArray(3) { -1f }; val good = FloatArray(3) { -1f }
        val seen = BooleanArray(w * h)
        val stack = IntArray(w * h)
        for (start in 0 until w * h) {
            if (!dil[start] || seen[start]) continue
            var sp = 0; stack[sp++] = start; seen[start] = true
            var minX = w; var maxX = 0; var minY = h; var maxY = 0
            var cnt = 0; var coin = 0; var green = 0; var white = 0
            while (sp > 0) {
                val i = stack[--sp]; val y = i / w; val x = i % w
                if (mask[i]) {
                    cnt++
                    if (x < minX) minX = x; if (x > maxX) maxX = x
                    if (y < minY) minY = y; if (y > maxY) maxY = y
                    val p = px[i]; val rr = r(p); val gg = g(p); val bb = b(p)
                    val mx = max(rr, max(gg, bb)); val mn = min(rr, min(gg, bb))
                    if (rr > 180 && gg > 140 && bb < 110) coin++
                    if (gg > rr + 15 && gg > bb + 5 && mx > 50) green++
                    if (mn > 170 && mx - mn < 40) white++
                }
                if (x > 0 && dil[i - 1] && !seen[i - 1]) { seen[i - 1] = true; stack[sp++] = i - 1 }
                if (x < w - 1 && dil[i + 1] && !seen[i + 1]) { seen[i + 1] = true; stack[sp++] = i + 1 }
                if (y > 0 && dil[i - w] && !seen[i - w]) { seen[i - w] = true; stack[sp++] = i - w }
                if (y < h - 1 && dil[i + w] && !seen[i + w]) { seen[i + w] = true; stack[sp++] = i + w }
            }
            if (cnt < 25) continue
            val bw = maxX - minX + 1; val bh = maxY - minY + 1
            val cxm = (minX + maxX + 1) / 2f / w
            val ln = (((cxm - ROAD_L) / (ROAD_R - ROAD_L)) * 3).toInt().coerceIn(0, 2)
            val yTopF = minY.toFloat() / h; val yBotF = (maxY + 1).toFloat() / h

            val isCoin = coin.toFloat() / cnt > 0.5f                        // عملة ذهبية: تُلتقط
            val isBubble = isCoin || bw >= 0.13f * w && bw <= 0.30f * w && bh >= 0.13f * w && bh <= 0.30f * w &&
                bw.toFloat() / bh in 0.75f..1.33f &&
                green.toFloat() / cnt < 0.03f && white.toFloat() / cnt >= 0.05f &&
                rimScore(px, w, h, (minX + maxX + 1) / 2f, (minY + maxY + 1) / 2f, min(bw, bh) / 2f - 1.5f) >= 0.6f

            if (isBubble) { if (yBotF > good[ln]) good[ln] = yBotF }
            else if (yTopF < 0.68f) { if (yBotF > haz[ln]) haz[ln] = yBotF }   // عائق لم يتجاوز السيارة بعد
        }

        // نسبة الأسفلت + زر القائمة
        var asp = 0; var tot = 0
        var yy = 0
        while (yy < h) { var xx = x0; while (xx < x1) {
            val p = px[yy * w + xx]; val rr = r(p); val gg = g(p); val bb = b(p)
            val mx = max(rr, max(gg, bb)); val mn = min(rr, min(gg, bb))
            if (mx < 95 && mx - mn < 40 && bb >= rr - 5) asp++
            tot++; xx += 3 }; yy += 3 }
        var btn = 0; var bt = 0
        for (y in (0.77f * h).toInt() until (0.83f * h).toInt()) for (x in (0.35f * w).toInt() until (0.65f * w).toInt()) {
            val p = px[y * w + x]
            if (r(p) > 200 && g(p) in 111..199 && b(p) < 90) btn++; bt++
        }
        return Result(car, haz, good, asp.toFloat() / tot, bt > 0 && btn.toFloat() / bt > 0.3f)
    }

    /** نسبة نقاط محيط الدائرة التي فيها حافة فاتحة قليلة التشبع (حافة الفقاعة الزجاجية). */
    private fun rimScore(px: IntArray, w: Int, h: Int, cx: Float, cy: Float, rad: Float): Float {
        var ok = 0
        for (a in 0 until 32) {
            val t = a * 2.0 * Math.PI / 32
            val x = Math.round(cx + rad * cos(t)).toInt(); val y = Math.round(cy + rad * sin(t)).toInt()
            if (x < 0 || x >= w || y < 0 || y >= h) continue
            var hit = false
            for (dy in -1..1) for (dx in -1..1) {
                val xx = x + dx; val yy = y + dy
                if (xx < 0 || xx >= w || yy < 0 || yy >= h) continue
                val p = px[yy * w + xx]; val mx = max(r(p), max(g(p), b(p))); val mn = min(r(p), min(g(p), b(p)))
                if (mn >= 70 && mx - mn <= 45) hit = true
            }
            if (hit) ok++
        }
        return ok / 32f
    }
}
