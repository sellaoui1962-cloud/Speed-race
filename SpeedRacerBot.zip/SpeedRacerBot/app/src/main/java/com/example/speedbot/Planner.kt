package com.example.speedbot

import kotlin.math.abs

/** يقرر: -1 يسار، +1 يمين، 0 ابقَ. العتبات تتكيف مع سرعة الطريق (speed = جزء من ارتفاع الشاشة/ثانية). */
object Planner {
    private const val CAR_TOP = 0.535f

    private fun clear(y: Float, limit: Float) = y < 0f || y < limit

    fun decide(r: Vision.Result, car: Int, speed: Float): Int {
        if (car < 0) return 0
        val haz = r.haz
        // كلما زادت السرعة نبكّر بالهروب (زمن الرد ≈ 0.25ث لتغيير المسار + تأخر الالتقاط)
        val dangerY = (CAR_TOP - (0.10f + 0.5f * speed)).coerceIn(0.12f, 0.40f)
        val enterY = (CAR_TOP - speed * 0.30f - 0.04f).coerceIn(0.25f, 0.50f)

        var best = car; var bestScore = score(car, car, r, dangerY)
        for (t in 0..2) {
            if (t == car) continue
            val step = if (t > car) 1 else -1
            var ok = true; var l = car + step
            while (true) { if (!clear(haz[l], enterY)) ok = false; if (l == t) break; l += step }
            if (!ok) continue
            val s = score(t, car, r, dangerY)
            if (s > bestScore + 0.15f) { best = t; bestScore = s }
        }
        return Integer.signum(best - car)
    }

    private fun score(l: Int, c: Int, r: Vision.Result, dangerY: Float): Float {
        val h = r.haz[l]
        var s = if (h < 0f) 1.2f else 1f - h
        if (h >= 0f && h > dangerY) s -= 1.0f
        val f = r.good[l]
        if (f >= 0f && (h < 0f || f > h)) s += 0.6f
        s -= 0.1f * abs(l - c)
        return s
    }
}
